import { Component } from '@angular/core';

@Component({
    selector: 'app-tipo-movimento',
    templateUrl: './tipo-movimento.component.html'
})
export class TipoMovimentoComponent { }
