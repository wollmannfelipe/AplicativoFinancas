import { Component } from '@angular/core';

@Component({
    selector: 'app-conta',
    templateUrl: './conta.component.html'
})
export class ContaComponent { }
