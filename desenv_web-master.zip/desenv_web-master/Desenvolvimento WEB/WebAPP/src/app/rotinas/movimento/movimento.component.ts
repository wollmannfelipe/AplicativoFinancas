import { Component } from '@angular/core';

@Component({
    selector: 'app-movimento',
    templateUrl: './movimento.component.html'
})
export class MovimentoComponent { }
