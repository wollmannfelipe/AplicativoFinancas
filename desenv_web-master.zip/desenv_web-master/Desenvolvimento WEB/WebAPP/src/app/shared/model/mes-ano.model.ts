export class MesAno {
    Mes: number;
    Ano: number;
    Descricao: string;
}
