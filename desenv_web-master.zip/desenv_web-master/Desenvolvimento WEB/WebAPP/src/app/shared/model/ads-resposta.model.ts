export class ADSResposta {
    Sucesso: boolean;
    Mensagem: string;
    Objeto: any;
}
