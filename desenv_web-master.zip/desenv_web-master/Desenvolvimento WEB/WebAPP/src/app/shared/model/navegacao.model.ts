export class Navegacao {
    Endereco: string;
    Icone: string;
    Titulo: string;
}
