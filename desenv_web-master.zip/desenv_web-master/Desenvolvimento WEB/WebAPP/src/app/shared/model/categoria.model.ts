import { Movimento } from './movimento.model';

export class Categoria {
    Codigo: string;
    Descricao: string;
    Movimentos: Array<Movimento>;
}
