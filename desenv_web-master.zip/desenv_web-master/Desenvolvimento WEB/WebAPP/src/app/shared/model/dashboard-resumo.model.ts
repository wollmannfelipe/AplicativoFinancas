import { MesAno } from './mes-ano.model';

export class DashBoardResumo {
    DespesasAberto: number;
    ReceitasAberto: number;
    SaldoContas: number;
    Previsao: number;
}
