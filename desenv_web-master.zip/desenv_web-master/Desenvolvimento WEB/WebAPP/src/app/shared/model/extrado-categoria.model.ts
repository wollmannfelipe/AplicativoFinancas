import { Categoria } from './categoria.model';

export class ExtratoCategoria {
    Ordem: number;
    Credito: number;
    Debito: number;
    Categoria: Categoria;
}
