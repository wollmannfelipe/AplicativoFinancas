﻿namespace BancoDeDados
{
    public class ContaView
    {
        public string Codigo { get; set; }
        public string Descricao { get; set; }
    }
}
