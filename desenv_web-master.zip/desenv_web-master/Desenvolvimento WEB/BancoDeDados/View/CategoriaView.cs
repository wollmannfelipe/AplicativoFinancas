﻿namespace BancoDeDados
{
    public class CategoriaView
    {
        public string Codigo { get; set; }
        public string Descricao { get; set; }
    }
}
